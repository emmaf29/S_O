



class Hueco:

    # Simularia el espacio en memoria fisica como una lista con bases y limites.
        
    def __init__(self):
        pass
    