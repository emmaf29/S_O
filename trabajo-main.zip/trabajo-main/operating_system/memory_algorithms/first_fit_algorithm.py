

class FirstFitAlgorithm:
    def __init__(self):
        pass


    def load(self, data):
        pass



